package com.example.vanthinh.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }
    public void submit(View view){
        String name;
        EditText editText = (EditText) findViewById(R.id.editText);
        name = editText.getText().toString();
        Toast.makeText(this,"Thank you for order, " + name,Toast.LENGTH_LONG).show();
    }
}
