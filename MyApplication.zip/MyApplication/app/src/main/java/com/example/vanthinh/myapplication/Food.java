package com.example.vanthinh.myapplication;

/**
 * Created by Van Thinh on 11/3/2017.
 */

public class Food {
    private String name;
    private String description;
    private int imageid;

    public static final Food [] foods = {
        new Food("pizza","topped with tomato sauce and cheese",R.drawable.pizza),
        new Food("burger","savory fire-grilled beef,  bacon, melted American cheese, lettuce, tomatoes, onions, pickles, bbq sauce", R.drawable.burger),
        new Food("sandwich","vegetables, sliced cheese and meat",R.drawable.sandwich)
    };
    public Food(String name, String description, int imageid){
        this.name = name;
        this.description = description;
        this.imageid = imageid;
    }
    public String getName() {
        return name;
    }
    public String getDescription(){
        return description;
    }
    public String toString() {
        return this.name;
    }
    public int getImageid(){return imageid;}
}
