package com.example.vanthinh.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FoodActivity extends AppCompatActivity {
    public static final String EXTRA_FOODNO ="foodno";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        int foodno = (Integer) getIntent().getExtras().get(EXTRA_FOODNO);
        Food food = Food.foods[foodno];

        TextView name =(TextView) findViewById(R.id.name);
        TextView desc = (TextView) findViewById(R.id.desc);
        ImageView image = (ImageView) findViewById(R.id.imageid);

        name.setText(food.getName());
        desc.setText(food.getDescription());
        image.setImageResource(food.getImageid());
    }
//    public void pushToList(View view){
//        int foodno = (Integer) getIntent().getExtras().get(EXTRA_FOODNO);
//        Food food = Food.foods[foodno];
//        Intent intent = new Intent(this,MainActivity.class);
////        Bundle bundle = new Bundle();
////        bundle.putString("array",food.getName() );
//        intent.putExtra("a",food.getName());
//        setResult(MainActivity.RESULT_OK, intent);
//    }
}
