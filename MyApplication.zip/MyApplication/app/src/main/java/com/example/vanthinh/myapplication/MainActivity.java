package com.example.vanthinh.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    String item ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("Mainactivity tag", "onCreate: Mainactivity");
        setContentView(R.layout.activity_main);

        ArrayList<String> list = new ArrayList<String>();


        list.add(item);
//        String show = "";
//        TextView textView   = (TextView) findViewById(R.id.list_order);
//        for (int i =0; i< list.size();i++){
//            show +=list.get(i)+"/n";
//        }
//        textView.setText(show);


        AdapterView.OnItemClickListener itemListener = new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> ListView, View view, int position, long id) {
                if (position ==0){
                    Intent intent = new Intent(MainActivity.this,FoodCate.class);
                    startActivity(intent);
                }
                if (position ==1){
                    Intent intent = new Intent(MainActivity.this,ShopInfo.class);
                    startActivity(intent);
                }
                if (position ==2){
                    Intent intent =new Intent(MainActivity.this, Info.class);
                    startActivity(intent);
                }

            }


        };
        ListView listView = (ListView) findViewById(R.id.list_options);
        listView.setOnItemClickListener(itemListener);
    }



    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("Mainactivity tag", "onRestart: Mainactivity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Mainactivity tag", "onPause: Mainactivity");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Mainactivity tag", "onResume: Mainactivity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Mainactivity tag", "onStop: Mainactivity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("Mainactivity tag", "onDestroy: Mainactivity");
    }
}
