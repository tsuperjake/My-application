package com.example.vanthinh.myapplication;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FoodCate extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView listfood = getListView();
        Log.i("FoodCate tag", "onCreate: FoodCate");
        ArrayAdapter<Food> listAdapter = new ArrayAdapter<Food>(this,android.R.layout.simple_list_item_1,Food.foods);
        listfood.setAdapter(listAdapter);
    }

    @Override
    protected void onListItemClick(ListView listView, View itemview, int position, long id) {
        super.onListItemClick(listView, itemview, position, id);
        Intent intent = new Intent(FoodCate.this,FoodActivity.class);
        intent.putExtra(FoodActivity.EXTRA_FOODNO,(int) id);
        startActivity(intent);
        Log.i("FoodCate tag", "id: "+String.valueOf(id));
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("FoodCate tag", "onRestart: FoodCate");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("FoodCate tag", "onPause: FoodCate");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("FoodCate tag", "onResume: FoodCate");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("FoodCate tag", "onStop: FoodCate");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("FoodCate tag", "onDestroy: FoodCate");
    }
}
